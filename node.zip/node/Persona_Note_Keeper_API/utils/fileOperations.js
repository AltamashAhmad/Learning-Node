import fs from 'fs/promises';

const DATA_FILE = './data/notes.json';

// Helper function to read notes from file
export async function readNotes() {
    try {
        const data = await fs.readFile(DATA_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading notes:', error);
        return [];
    }
}

// Helper function to write notes to file
export async function writeNotes(notes) {
    try {
        await fs.writeFile(DATA_FILE, JSON.stringify(notes, null, 2));
    } catch (error) {
        console.error('Error writing notes:', error);
        throw error;
    }
}

// Helper function to generate unique ID
export function generateId() {
    return Date.now().toString();
}
