
import http from 'http';
import { URL } from 'url';
import { getAllNotes, getNoteById, createNote, updateNote, deleteNote } from './routes/notes.js';

const PORT = 3001;

const server = http.createServer(async (req, res) => {
    const { method, url } = req;
    
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    
    // Handle preflight requests
    if (method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }

    try {
        // Parse URL
        const parsedUrl = new URL(url, `http://localhost:${PORT}`);
        const pathname = parsedUrl.pathname;
        const pathSegments = pathname.split('/').filter(segment => segment);

        // Route handling
        if (pathSegments[0] === 'notes') {
            if (method === 'GET' && pathSegments.length === 1) {
                // GET /notes - Get all notes
                await getAllNotes(req, res);
                return;
            }
            
            if (method === 'GET' && pathSegments.length === 2) {
                // GET /notes/:id - Get a note by ID
                const id = pathSegments[1];
                await getNoteById(req, res, id);
                return;
            }
            
            if (method === 'POST' && pathSegments.length === 1) {
                // POST /notes - Create a new note
                await createNote(req, res);
                return;
            }
            
            if (method === 'PUT' && pathSegments.length === 2) {
                // PUT /notes/:id - Update a note by ID
                const id = pathSegments[1];
                await updateNote(req, res, id);
                return;
            }
            
            if (method === 'DELETE' && pathSegments.length === 2) {
                // DELETE /notes/:id - Delete a note by ID
                const id = pathSegments[1];
                await deleteNote(req, res, id);
                return;
            }
        }

        // Default 404 response
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Not Found' }));

    } catch (error) {
        console.error('Server error:', error);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Internal Server Error' }));
    }
});


server.listen(PORT, 'localhost', () => {
  console.log(`Server running at http://localhost:${PORT}/`);
});