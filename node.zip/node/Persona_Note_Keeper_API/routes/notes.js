import { readNotes, writeNotes, generateId } from '../utils/fileOperations.js';

// Helper function to parse request body
function parseBody(req) {
    return new Promise((resolve, reject) => {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });
        req.on('end', () => {
            try {
                resolve(body ? JSON.parse(body) : {});
            } catch (error) {
                reject(error);
            }
        });
    });
}

// GET /notes - Get all notes
export async function getAllNotes(req, res) {
    try {
        const notes = await readNotes();
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(notes));
    } catch (error) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Error fetching notes' }));
    }
}

// GET /notes/:id - Get a note by ID
export async function getNoteById(req, res, id) {
    try {
        const notes = await readNotes();
        const note = notes.find(note => note.id === id);
        
        if (note) {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(note));
        } else {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: 'Note not found' }));
        }
    } catch (error) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Error fetching note' }));
    }
}

// POST /notes - Create a new note
export async function createNote(req, res) {
    try {
        const body = await parseBody(req);
        
        if (!body.title || !body.content) {
            res.writeHead(400, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: 'Title and content are required' }));
            return;
        }

        const notes = await readNotes();
        const newNote = {
            id: generateId(),
            title: body.title,
            content: body.content,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };

        notes.push(newNote);
        await writeNotes(notes);

        res.writeHead(201, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(newNote));
    } catch (error) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Error creating note' }));
    }
}

// PUT /notes/:id - Update a note by ID
export async function updateNote(req, res, id) {
    try {
        const body = await parseBody(req);
        const notes = await readNotes();
        const noteIndex = notes.findIndex(note => note.id === id);
        
        if (noteIndex === -1) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: 'Note not found' }));
            return;
        }

        // Update the note
        const updatedNote = {
            ...notes[noteIndex],
            title: body.title || notes[noteIndex].title,
            content: body.content || notes[noteIndex].content,
            updatedAt: new Date().toISOString()
        };

        notes[noteIndex] = updatedNote;
        await writeNotes(notes);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(updatedNote));
    } catch (error) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Error updating note' }));
    }
}

// DELETE /notes/:id - Delete a note by ID
export async function deleteNote(req, res, id) {
    try {
        const notes = await readNotes();
        const noteIndex = notes.findIndex(note => note.id === id);
        
        if (noteIndex === -1) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ message: 'Note not found' }));
            return;
        }

        const deletedNote = notes.splice(noteIndex, 1)[0];
        await writeNotes(notes);

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Note deleted successfully', note: deletedNote }));
    } catch (error) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Error deleting note' }));
    }
}
